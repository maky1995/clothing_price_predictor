
import os
from pathlib import Path

import joblib
import pandas as pd
import streamlit as st
from sklearn.ensemble import RandomForestRegressor
from sklearn.preprocessing import OneHotEncoder

BASE_DIR = Path(__file__).resolve().parent
MODEL_FILE = BASE_DIR / "Price_Quota_Model.pkl"
ENCODER_FILE = BASE_DIR / "price_encoder.pkl"

CSV_CANDIDATES = [
    BASE_DIR / "Clothing_dataset.csv",
    BASE_DIR / "clothing_dataset.csv",
]
EXCEL_CANDIDATES = [
    BASE_DIR / "Overfitting clothing_dataset.xlsx",
]

FEATURES = ["category", "gender", "brand", "fabric", "pattern", "occasion", "length"]

DROP_COLUMNS = [
    "product_id", "product_title", "fit", "neck", "closure",
    "sleeve_length", "currency", "description", "material_and_care",
    "discount_pct", "final_price", "all_image_urls", "rating",
    "ratings_count", "primary_image_url", "Unnamed: 23"
]


def clean_num(series):
    return pd.to_numeric(
        series.astype(str).str.replace(r"[^\d.]", "", regex=True),
        errors="coerce",
    )


def load_dataset():
    for path in CSV_CANDIDATES:
        if path.exists():
            return pd.read_csv(path)

    for path in EXCEL_CANDIDATES:
        if path.exists():
            return pd.read_excel(path)

    raise FileNotFoundError(
        "Dataset not found. Put Clothing_dataset.csv in the same folder as app.py."
    )


def prepare_data(df):
    df = df.copy()

    # Match the cleaning logic used in the training notebook.
    df = df.drop(columns=DROP_COLUMNS, errors="ignore")

    # The notebook removed corrupted rows at the end of the dataset.
    if len(df) > 346:
        df = df.iloc[:346].copy()

    missing_features = [c for c in FEATURES if c not in df.columns]
    if missing_features:
        raise ValueError(f"Missing required columns: {missing_features}")

    for col in FEATURES:
        df[col] = df[col].fillna(
            df[col].mode().iloc[0] if not df[col].mode().empty else "Unknown"
        ).astype(str)

    df["initial_price"] = clean_num(df["initial_price"])
    df["initial_price"] = df["initial_price"].fillna(df["initial_price"].median())

    df = df.dropna(subset=["initial_price"])

    return df


def train_and_save():
    df = prepare_data(load_dataset())
    X = df[FEATURES]
    y = df["initial_price"]

    encoder = OneHotEncoder(handle_unknown="ignore", sparse_output=False)
    X_encoded = encoder.fit_transform(X)

    model = RandomForestRegressor(
        n_estimators=100,
        random_state=42
    )
    model.fit(X_encoded, y)

    # Save both objects so Streamlit can transform new inputs correctly.
    joblib.dump(model, MODEL_FILE)
    joblib.dump(encoder, ENCODER_FILE)

    return model, encoder, df


@st.cache_resource
def load_model():
    if MODEL_FILE.exists() and ENCODER_FILE.exists():
        return joblib.load(MODEL_FILE), joblib.load(ENCODER_FILE), None

    return train_and_save()


@st.cache_data
def get_choices():
    df = prepare_data(load_dataset())
    return {
        col: sorted(df[col].dropna().astype(str).unique().tolist())
        for col in FEATURES
    }


st.set_page_config(
    page_title="Clothing Price Predictor",
    page_icon="👗",
    layout="centered",
)

st.title("👗 Clothing Price Predictor")
st.write(
    "Enter the clothing details below and the machine-learning model will "
    "estimate the item's initial price."
)

try:
    model, encoder, training_df = load_model()
    choices = get_choices()

    st.success("Model loaded successfully.")

    with st.form("prediction_form"):
        st.subheader("Clothing Details")

        category = st.selectbox("Category", choices["category"])
        gender = st.selectbox("Gender", choices["gender"])
        brand = st.selectbox("Brand", choices["brand"])
        fabric = st.selectbox("Fabric", choices["fabric"])
        pattern = st.selectbox("Pattern", choices["pattern"])
        occasion = st.selectbox("Occasion", choices["occasion"])
        length = st.selectbox("Length", choices["length"])

        submitted = st.form_submit_button(
            "💰 Predict Clothing Price",
            use_container_width=True
        )

    if submitted:
        input_df = pd.DataFrame([{
            "category": category,
            "gender": gender,
            "brand": brand,
            "fabric": fabric,
            "pattern": pattern,
            "occasion": occasion,
            "length": length,
        }])

        encoded_input = encoder.transform(input_df)
        prediction = float(model.predict(encoded_input)[0])

        st.markdown("---")
        st.subheader("Estimated Initial Price")
        st.metric("Predicted Price", f"₹{prediction:,.2f}")
        st.caption("The model was trained on the clothing dataset supplied for this project.")

except FileNotFoundError as e:
    st.error(str(e))
    st.info(
        "Place Clothing_dataset.csv in this folder, then run the app again."
    )
except Exception as e:
    st.error(f"Something went wrong: {e}")
    st.info(
        "If you changed the dataset or scikit-learn version, delete the .pkl "
        "files and restart the app so they can be regenerated."
    )

st.markdown("---")
st.caption("Machine Learning Project • Random Forest Regression")
