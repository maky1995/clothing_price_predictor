
from pathlib import Path
import joblib
import pandas as pd
from sklearn.ensemble import RandomForestRegressor
from sklearn.preprocessing import OneHotEncoder

BASE_DIR = Path(__file__).resolve().parent
MODEL_FILE = BASE_DIR / "Price_Quota_Model.pkl"
ENCODER_FILE = BASE_DIR / "price_encoder.pkl"

FEATURES = ["category", "gender", "brand", "fabric", "pattern", "occasion", "length"]

DROP_COLUMNS = [
    "product_id", "product_title", "fit", "neck", "closure",
    "sleeve_length", "currency", "description", "material_and_care",
    "discount_pct", "final_price", "all_image_urls", "rating",
    "ratings_count", "primary_image_url", "Unnamed: 23"
]


def clean_num(series):
    return pd.to_numeric(
        series.astype(str).str.replace(r"[^\d.]", "", regex=True),
        errors="coerce",
    )


def main():
    csv = BASE_DIR / "Clothing_dataset.csv"
    if not csv.exists():
        raise FileNotFoundError(
            "Clothing_dataset.csv was not found. Put it beside train_model.py."
        )

    df = pd.read_csv(csv)
    df = df.drop(columns=DROP_COLUMNS, errors="ignore")

    if len(df) > 346:
        df = df.iloc[:346].copy()

    for col in FEATURES:
        df[col] = df[col].fillna(
            df[col].mode().iloc[0] if not df[col].mode().empty else "Unknown"
        ).astype(str)

    df["initial_price"] = clean_num(df["initial_price"])
    df["initial_price"] = df["initial_price"].fillna(df["initial_price"].median())
    df = df.dropna(subset=["initial_price"])

    X = df[FEATURES]
    y = df["initial_price"]

    encoder = OneHotEncoder(handle_unknown="ignore", sparse_output=False)
    X_encoded = encoder.fit_transform(X)

    model = RandomForestRegressor(n_estimators=100, random_state=42)
    model.fit(X_encoded, y)

    joblib.dump(model, MODEL_FILE)
    joblib.dump(encoder, ENCODER_FILE)

    print(f"Saved model to: {MODEL_FILE}")
    print(f"Saved encoder to: {ENCODER_FILE}")
    print(f"Training rows: {len(df)}")
    print(f"Features: {FEATURES}")


if __name__ == "__main__":
    main()
