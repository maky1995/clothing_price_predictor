
# Clothing Price Predictor — Streamlit

This project turns the trained clothing price prediction work into a Streamlit web app.

## Files

- `app.py` — Streamlit user interface and prediction logic.
- `train_model.py` — retrains the Random Forest model and saves the model + encoder.
- `requirements.txt` — Python packages required.
- `Clothing_dataset.csv` — **you must place your dataset here**.

## Run locally

1. Put `Clothing_dataset.csv` in this same folder.
2. Open a terminal in the folder.
3. Install packages:

```bash
pip install -r requirements.txt
```

4. Start the app:

```bash
streamlit run app.py
```

The first run automatically trains and saves:

- `Price_Quota_Model.pkl`
- `price_encoder.pkl`

The encoder is saved separately because the model needs the same OneHotEncoder used during training to process new user inputs.

## Important

The original notebook uses a RandomForestRegressor and OneHotEncoder. It also removes several non-predictive columns and keeps these prediction inputs:

`category, gender, brand, fabric, pattern, occasion, length`

The original notebook saved the model but did not save the encoder. This version fixes that deployment issue.

The model predicts the dataset's `initial_price`, which is in INR because the source dataset uses `INR`.
